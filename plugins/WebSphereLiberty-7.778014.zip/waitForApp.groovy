/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2013. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.plugin.websphereliberty.WebSphereLibertyJMXHelper;
import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties();
def userName = props['userName'];
def userPassword = props['userPassword'];
def appName = props['appName'];
def waitTimeout = props['waitTimeout'];
def server = props['server'];
def httpsPort = props['httpsPort'];
def trustStorePath = props['trustStorePath'];
def trustStorePassword = props['trustStorePassword'];

def state = props['state'];
if (this.args.size() >= 3) {
    state = this.args[2];
}

try {
    waitTimeout = Long.valueOf(waitTimeout);
}
catch (NumberFormatException e) {
    System.out.println("Wait Timeout must be a long!");
    System.exit(1);
}


def jmxHelper = new WebSphereLibertyJMXHelper(userName, userPassword, server, httpsPort, trustStorePath, trustStorePassword);
jmxHelper.waitForApplication(appName, state, waitTimeout);
