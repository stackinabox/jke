import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphereliberty.WebSphereLibertyHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties();

def source = props['source'];
def wlpHome = props['wlpHome'];
def serverName = props['server'];

def wslh = new WebSphereLibertyHelper(wlpHome);
wslh.uninstallViaDropins(serverName, source);
